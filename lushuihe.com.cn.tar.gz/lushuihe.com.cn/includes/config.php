<?php
$db_host='localhost';
$db_user='lushuihe';
$db_password='lushuihe888';
$db_name='lushuihe';
$db_prefix='oss_';
?>
