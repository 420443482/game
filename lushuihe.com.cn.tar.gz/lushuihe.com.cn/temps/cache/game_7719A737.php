<?php exit;?>a:3:{s:8:"template";a:7:{i:0;s:53:"/www/wwwroot/lushuihe.com.cn/templates/kele/game.html";i:1;s:55:"/www/wwwroot/lushuihe.com.cn/templates/kele/header.html";i:2;s:61:"/www/wwwroot/lushuihe.com.cn/templates/kele/index_header.html";i:3;s:59:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_login.html";i:4;s:57:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_faq.html";i:5;s:61:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_service.html";i:6;s:55:"/www/wwwroot/lushuihe.com.cn/templates/kele/footer.html";}s:7:"expires";i:1544189524;s:8:"maketime";i:1544185924;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>LT一站式遊戲充值平台.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="遊戲,充值" />
<meta name="description" content="LT遊戲充值平台" />
<LINK href="/templates/kele/img/reset.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/common.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/gamelist.css" type=text/css rel=stylesheet>
<!--[if lte IE 6]>
<script src="/templates/kele/img/fixPNG.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('.pngfix');
</script>
<![endif]--> 
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<DIV id=header>
  <DIV class=top>
    <IMG class=pngfix id=logo src="/templates/kele/img/logo.png">
    <UL class="q_nav fr">
      <LI>
        <P class=fl><A class="icon i_reg" title=註冊 href="reg.php">註冊</A> <A class="icon i_log" title=登錄 href="login.php">登錄</A> <A class="icon i_pay" title=帳戶充值 href="pay.php">帳戶充值</A> </P>
        <P class=fr><A title=中文繁體 href="/">中文繁體</A>| <A title=ENGLISH href="en_index.php">ENGLISH</A></P>
      </LI>
    </UL>
  </DIV>
  <UL id=nav>
    <LI class=menu>
    	    	    		<A class="spe" href="/" >首頁</A>
    	    		<A class="spe" href="game.php" >遊戲中心</A>
    	    		<A class="spe" href="news.php" >遊戲動態</A>
    	    		<A class="spe" href="pay.php" >充值中心</A>
    	    		<A class="spe" href="card.php" >新手禮包</A>
    	    	    </LI>
    <LI class=s_msg style="display:none">
      <P class="fl icon i_laba">您好！如果您在遊戲過程中遇到任何問題，可以諮詢我們的線上客服幫您解決。</P>
      <P class=fr></P>
    </LI>
  </UL>
</DIV>
<div id="lunbo" style="z-index:-99;margin-top:-90px">
<link rel="stylesheet" type="text/css" href="templates/kele/css/demo-style.css">
<script type="text/javascript" src="templates/kele/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="templates/kele/js/banner.js"></script>
		<div id="xc" class="containerflash " style="z-index:-1">
		<div id="featured"> 	
<img src="templates/kele/images/q1.jpg"  style="z-index: 1; display: none;">
<img src="templates/kele/images/q2.jpg"  style="z-index: 2; display: none;">
<img src="templates/kele/images/q3.jpg"  style="z-index: 3; display: block;">
				  <div class="num">
                            <p class="lc"></p>
                            <p class="mc" id="numinner"><span class=""></span><span class=""></span><span class="on"></span>   </p>
                            <p class="rc"></p>
          </div>
		  </div>
	</div>
</div>
<div id="main_index" style="margin-top:-200px; z-index:999">
<!--<DIV id=header>
  <DIV class=top>
    <IMG class=pngfix id=logo src="/templates/kele/img/logo.png">
    <UL class="q_nav fr">
      <LI>
        <P class=fl><A class="icon i_reg" title=註冊 href="reg.php">註冊</A> <A class="icon i_log" title=登錄 href="login.php">登錄</A> <A class="icon i_pay" title=帳戶充值 href="pay.php">帳戶充值</A> </P>
        <P class=fr><A title=中文繁體 href="/">中文繁體</A>| <A title=ENGLISH href="en_index.php">ENGLISH</A></P>
      </LI>
    </UL>
  </DIV>
  <UL id=nav>
    <LI class=menu>-->
    	    	    	<!--	<A class="spe" href="/" >首頁</A>--->
    	    	<!--	<A class="spe" href="game.php" >遊戲中心</A>--->
    	    	<!--	<A class="spe" href="news.php" >遊戲動態</A>--->
    	    	<!--	<A class="spe" href="pay.php" >充值中心</A>--->
    	    	<!--	<A class="spe" href="card.php" >新手禮包</A>--->
    	    	   <!-- </LI>
    <LI class=s_msg>
      <P class="fl icon i_laba">您好！如果您在遊戲過程中遇到任何問題，可以諮詢我們的線上客服幫您解決。</P>
      <P class=fr></P>
    </LI>
  </UL>
</DIV>-->
 
<DIV class="mainContent clearfix">
  <DIV class="left box game_center">
    <h3 class="gl"><strong class="fl pngfix hid">遊戲中心</strong></h3>
    <DIV class=margin>
<ul class="g_list clearfix">
<li><a href="game.php?action=server_list&game_id=56"><img class="fl" src="uploads/20180808161805_ifsktn.jpg"></a>
  <div class="fl">
    <p><strong>開天戰神</strong><br>
      <a class="a1" href="card.php?game_id=56">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=56">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=55"><img class="fl" src="uploads/20180808161739_vegpnt.jpg"></a>
  <div class="fl">
    <p><strong>赤月傳說2</strong><br>
      <a class="a1" href="card.php?game_id=55">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=55">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=54"><img class="fl" src="uploads/20180808161718_ipaqbl.jpg"></a>
  <div class="fl">
    <p><strong>天劍狂刀</strong><br>
      <a class="a1" href="card.php?game_id=54">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=54">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=53"><img class="fl" src="uploads/20180808161646_yfftjw.jpg"></a>
  <div class="fl">
    <p><strong>蠻荒之怒</strong><br>
      <a class="a1" href="card.php?game_id=53">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=53">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=52"><img class="fl" src="uploads/20180808161622_jjqjdg.jpg"></a>
  <div class="fl">
    <p><strong>熱血三國2</strong><br>
      <a class="a1" href="card.php?game_id=52">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=52">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=51"><img class="fl" src="uploads/20180808161558_ndwaok.jpg"></a>
  <div class="fl">
    <p><strong>大明征途</strong><br>
      <a class="a1" href="card.php?game_id=51">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=51">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=50"><img class="fl" src="uploads/20180808161536_juoivc.jpg"></a>
  <div class="fl">
    <p><strong>鬥羅大陸</strong><br>
      <a class="a1" href="card.php?game_id=50">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=50">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=49"><img class="fl" src="uploads/20180808161511_trqbuz.jpg"></a>
  <div class="fl">
    <p><strong>冰火之劍</strong><br>
      <a class="a1" href="card.php?game_id=49">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=49">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=48"><img class="fl" src="uploads/20180808161453_oobgqw.jpg"></a>
  <div class="fl">
    <p><strong>尋秦記</strong><br>
      <a class="a1" href="card.php?game_id=48">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=48">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=47"><img class="fl" src="uploads/20180808161431_csqrik.jpg"></a>
  <div class="fl">
    <p><strong>洪荒主宰</strong><br>
      <a class="a1" href="card.php?game_id=47">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=47">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=46"><img class="fl" src="uploads/20180808161408_adqmth.jpg"></a>
  <div class="fl">
    <p><strong>藍月傳奇</strong><br>
      <a class="a1" href="card.php?game_id=46">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=46">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=45"><img class="fl" src="uploads/20180808161346_vxjhbs.jpg"></a>
  <div class="fl">
    <p><strong>封天記</strong><br>
      <a class="a1" href="card.php?game_id=45">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=45">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=44"><img class="fl" src="uploads/20180808161324_fkdhoj.jpg"></a>
  <div class="fl">
    <p><strong>戰天</strong><br>
      <a class="a1" href="card.php?game_id=44">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=44">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=43"><img class="fl" src="uploads/20180808161305_ivzdcn.jpg"></a>
  <div class="fl">
    <p><strong>寒刀行</strong><br>
      <a class="a1" href="card.php?game_id=43">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=43">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=42"><img class="fl" src="uploads/20180808161238_fbugad.jpg"></a>
  <div class="fl">
    <p><strong>奇跡重生</strong><br>
      <a class="a1" href="card.php?game_id=42">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=42">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=41"><img class="fl" src="uploads/20180808161208_tebtgp.jpg"></a>
  <div class="fl">
    <p><strong>滅生</strong><br>
      <a class="a1" href="card.php?game_id=41">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=41">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=40"><img class="fl" src="uploads/20180808161140_yrkhiq.jpg"></a>
  <div class="fl">
    <p><strong>血盟榮耀</strong><br>
      <a class="a1" href="card.php?game_id=40">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=40">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=39"><img class="fl" src="uploads/20180808161112_sbxpvm.jpg"></a>
  <div class="fl">
    <p><strong>大皇帝</strong><br>
      <a class="a1" href="card.php?game_id=39">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=39">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=38"><img class="fl" src="uploads/20180808161051_owhvho.jpg"></a>
  <div class="fl">
    <p><strong>太極崛起</strong><br>
      <a class="a1" href="card.php?game_id=38">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=38">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=37"><img class="fl" src="uploads/20180808004803_fxusdy.jpg"></a>
  <div class="fl">
    <p><strong>風暴英雄</strong><br>
      <a class="a1" href="card.php?game_id=37">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=37">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=36"><img class="fl" src="uploads/20180808004739_sdpxge.jpg"></a>
  <div class="fl">
    <p><strong>逆戰</strong><br>
      <a class="a1" href="card.php?game_id=36">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=36">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=35"><img class="fl" src="uploads/20180808004717_qzlmmg.jpg"></a>
  <div class="fl">
    <p><strong>誅仙</strong><br>
      <a class="a1" href="card.php?game_id=35">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=35">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=34"><img class="fl" src="uploads/20180808004656_wmbwyh.jpg"></a>
  <div class="fl">
    <p><strong>龍之穀</strong><br>
      <a class="a1" href="card.php?game_id=34">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=34">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=33"><img class="fl" src="uploads/20180808004629_eukgfo.jpg"></a>
  <div class="fl">
    <p><strong>傳奇</strong><br>
      <a class="a1" href="card.php?game_id=33">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=33">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=32"><img class="fl" src="uploads/20180808004607_syyctx.jpg"></a>
  <div class="fl">
    <p><strong>太極</strong><br>
      <a class="a1" href="card.php?game_id=32">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=32">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=31"><img class="fl" src="uploads/20180808004546_fvbsam.jpg"></a>
  <div class="fl">
    <p><strong>神秘世界</strong><br>
      <a class="a1" href="card.php?game_id=31">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=31">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=30"><img class="fl" src="uploads/20180808004521_dhmnav.jpg"></a>
  <div class="fl">
    <p><strong>絕地求生：大逃殺</strong><br>
      <a class="a1" href="card.php?game_id=30">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=30">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=29"><img class="fl" src="uploads/20180808004448_ermiza.jpg"></a>
  <div class="fl">
    <p><strong>流放之路</strong><br>
      <a class="a1" href="card.php?game_id=29">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=29">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=28"><img class="fl" src="uploads/20180808004425_jutfmz.jpg"></a>
  <div class="fl">
    <p><strong>黑色沙漠</strong><br>
      <a class="a1" href="card.php?game_id=28">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=28">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=27"><img class="fl" src="uploads/20180808004400_dqanfj.jpg"></a>
  <div class="fl">
    <p><strong>冒險島</strong><br>
      <a class="a1" href="card.php?game_id=27">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=27">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=26"><img class="fl" src="uploads/20180808004320_gxeouz.jpg"></a>
  <div class="fl">
    <p><strong>天堂</strong><br>
      <a class="a1" href="card.php?game_id=26">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=26">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=25"><img class="fl" src="uploads/20180808004253_igoyav.jpg"></a>
  <div class="fl">
    <p><strong>艾爾之光</strong><br>
      <a class="a1" href="card.php?game_id=25">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=25">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=24"><img class="fl" src="uploads/20180808004225_qkmmmj.jpg"></a>
  <div class="fl">
    <p><strong>地下城與勇士</strong><br>
      <a class="a1" href="card.php?game_id=24">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=24">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=23"><img class="fl" src="uploads/20180808004145_uizfau.jpg"></a>
  <div class="fl">
    <p><strong>槍火遊俠</strong><br>
      <a class="a1" href="card.php?game_id=23">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=23">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=22"><img class="fl" src="uploads/20180808004121_hjruqe.jpg"></a>
  <div class="fl">
    <p><strong>CSGO</strong><br>
      <a class="a1" href="card.php?game_id=22">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=22">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=21"><img class="fl" src="uploads/20180808004057_hjnalx.jpg"></a>
  <div class="fl">
    <p><strong>變形金剛</strong><br>
      <a class="a1" href="card.php?game_id=21">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=21">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=20"><img class="fl" src="uploads/20180808004025_snjnye.jpg"></a>
  <div class="fl">
    <p><strong>穿越火線2</strong><br>
      <a class="a1" href="card.php?game_id=20">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=20">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=19"><img class="fl" src="uploads/20180808004000_oqydka.jpg"></a>
  <div class="fl">
    <p><strong>靈山奇緣</strong><br>
      <a class="a1" href="card.php?game_id=19">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=19">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=18"><img class="fl" src="uploads/20180808003937_qdxdlw.jpg"></a>
  <div class="fl">
    <p><strong>新天龍八部</strong><br>
      <a class="a1" href="card.php?game_id=18">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=18">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=17"><img class="fl" src="uploads/20180808003907_fcqwpf.jpg"></a>
  <div class="fl">
    <p><strong>坦克世界</strong><br>
      <a class="a1" href="card.php?game_id=17">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=17">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=16"><img class="fl" src="uploads/20180808003835_usoqby.jpg"></a>
  <div class="fl">
    <p><strong>爐石傳說</strong><br>
      <a class="a1" href="card.php?game_id=16">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=16">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=15"><img class="fl" src="uploads/20180808003806_ddxoid.jpg"></a>
  <div class="fl">
    <p><strong>夢幻西遊</strong><br>
      <a class="a1" href="card.php?game_id=15">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=15">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=14"><img class="fl" src="uploads/20180808003735_kjnrxd.jpg"></a>
  <div class="fl">
    <p><strong>傳奇霸業</strong><br>
      <a class="a1" href="card.php?game_id=14">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=14">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=13"><img class="fl" src="uploads/20180808003709_nylonp.jpg"></a>
  <div class="fl">
    <p><strong>魔獸世界</strong><br>
      <a class="a1" href="card.php?game_id=13">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=13">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=12"><img class="fl" src="uploads/20180808003635_atvtnw.jpg"></a>
  <div class="fl">
    <p><strong>DOTA2</strong><br>
      <a class="a1" href="card.php?game_id=12">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=12">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=11"><img class="fl" src="uploads/20180808003602_asqhek.jpg"></a>
  <div class="fl">
    <p><strong>我的世界</strong><br>
      <a class="a1" href="card.php?game_id=11">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=11">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=10"><img class="fl" src="uploads/20180808003534_xbfwmi.jpg"></a>
  <div class="fl">
    <p><strong>九陰真經2</strong><br>
      <a class="a1" href="card.php?game_id=10">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=10">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=9"><img class="fl" src="uploads/20180808003500_wevhsl.jpg"></a>
  <div class="fl">
    <p><strong>創世戰車</strong><br>
      <a class="a1" href="card.php?game_id=9">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=9">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=8"><img class="fl" src="uploads/20180808003358_vcrmff.jpg"></a>
  <div class="fl">
    <p><strong>守望先鋒</strong><br>
      <a class="a1" href="card.php?game_id=8">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=8">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=7"><img class="fl" src="uploads/20120314214107_tvbbnu.jpg"></a>
  <div class="fl">
    <p><strong>神仙道</strong><br>
      <a class="a1" href="card.php?game_id=7">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=7">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=6"><img class="fl" src="uploads/20120314122959_wclnct.jpg"></a>
  <div class="fl">
    <p><strong>龍將</strong><br>
      <a class="a1" href="card.php?game_id=6">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=6">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=5"><img class="fl" src="uploads/20120314122710_hjheqj.jpg"></a>
  <div class="fl">
    <p><strong>盛世三國</strong><br>
      <a class="a1" href="card.php?game_id=5">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=5">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=4"><img class="fl" src="uploads/20120308180959_wasmqu.jpg"></a>
  <div class="fl">
    <p><strong>凡人修真</strong><br>
      <a class="a1" href="card.php?game_id=4">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=4">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=3"><img class="fl" src="uploads/20120308180923_jkopnr.jpg"></a>
  <div class="fl">
    <p><strong>誅神</strong><br>
      <a class="a1" href="card.php?game_id=3">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=3">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=2"><img class="fl" src="uploads/20120308180839_aiiylr.jpg"></a>
  <div class="fl">
    <p><strong>傲劍</strong><br>
      <a class="a1" href="card.php?game_id=2">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=2">充值</a></p>
  </div>
</li>
<li><a href="game.php?action=server_list&game_id=1"><img class="fl" src="uploads/20120308180433_xozmnn.jpg"></a>
  <div class="fl">
    <p><strong>仙域</strong><br>
      <a class="a1" href="card.php?game_id=1">領取禮包</a><br>
	  <a class="a2"  target="_blank">熱玩遊戲</a>  </p>
    <p><a class="a4 hid" href="pay.php?game_id=1">充值</a></p>
  </div>
</li>
</ul>
    </DIV>
  </DIV>
  <DIV class=sidebar>
    <DIV class="" id=uc_box>
      <div id="Tab1">
  <form id="login_form" name="login_form" method="post" action="user.php?action=login_ok">
  <DIV class=login_b>
  <H3 class=hid>用戶登錄</H3>
  <DIV class="i clearfix">
    <LABEL class=fl for=txtUserName>用戶名：</LABEL>
    <P class=fl>
      <input id="member_username" name="member_username" type="text" />
    </P>
  </DIV>
  <DIV class="i clearfix">
    <LABEL class=fl for=txtPwd>密&nbsp;&nbsp;碼：</LABEL>
    <P class=fl>
      <input id="member_password" name="member_password" type="password" />
    </P>
  </DIV>
  <DIV class=b>
	<input id="login_submit" type="button" value="" class="hid cur" />
	<input name="post_mode" type="hidden" value="withtml5">
    <P>
      <input id="keeplive" type="checkbox" value="" checked="checked">
      <LABEL for=keeplive>記住登錄帳號</LABEL>
      <A title=找回密碼 href="user.php?action=forget">找回密碼</A> </P>
  </DIV>
  <DIV class=b2><A class=hid href="reg.php">註冊</A></DIV>
  </DIV>
  </form>
</div>
<script type="text/javascript">
	var logins=function(){
		var member_username=$('#member_username').val();
		var member_password=$('#member_password').val();
		if ($.trim(member_username)==''){
			alert('用戶名不能為空！');
			return false;
		}
		if ($.trim(member_password)==''){
			alert('密碼不能為空！');
			return false;
		}
		if (member_password.length<6&&member_password.length>20){
			alert('密碼由6-20個字元組成，建議使用英文字母加數位或符號的組合密碼。');
			return false;
		}
		
		$("#login_form").submit();
	};
	$("#login_submit").click(function(){
		logins();
	});
</script>
<div id="Tab2" style="display:none;">
<div class="login_a">
    <h3 class="hid">用戶登錄</h3>
    <div class="info">
        <img alt="avata" src="/templates/kele/img/avata.jpg">
        <dl>
            <dt><strong>歡迎登錄遊戲平臺！</strong></dt>
                <dd class="u_name"></dd>
        </dl>
    </div>
    <div class="b t_c">
        <a title="遊戲中心" href="game.php">遊戲中心</a>
        <a title="用戶中心" href="user.php">用戶中心</a>
        <a title="立即充值" href="pay.php">立即充值</a>
        <a title="禮包領取" href="card.php">禮包領取</a>
    </div>
    <div class="b2 t_c">
        <a title="安全退出" href="user.php?action=logout">安全退出</a>
    </div>
</div>
</div>
<script type="text/javascript">
var login_state=4f62c4718c80e165225fget_login_state|a:1:{s:4:"name";s:15:"get_login_state";}4f62c4718c80e165225f;
if(login_state==1){
	$("#Tab1").hide();
	$("#Tab2").show();
}
</script>
    </DIV>
    <DIV class="box latest_news">
      <h3><strong class="fl pngfix">常見問題</strong> <a title="更多" href="news.php?id=2" class="fr">更多&gt;&gt;</a></h3>
<DIV class=margin>
<ul class="list">
<li><a title="賬號被盜怎麼辦" href="content.php?id=9">賬號被盜怎麼辦</a> </li>
<li><a title="忘記密碼怎麼辦" href="content.php?id=8">忘記密碼怎麼辦</a> </li>
</ul>
</DIV>
    </DIV>
    <DIV class="box cs">
      <DIV class=margin>
      	<DIV class=cs_div>
          <H4 class=hid>客服中心</H4>
          <P>技術T E L：+8617620373555 </P>
          <P>在線郵箱：<a target="_blank" href="mailto:davejason702@gmail.com">davejason702@gmail.com</a> </P>
          <P><A class=c1 title=帳號申訴 href="#"><SPAN>帳號申訴</SPAN></A> <A class=c2 title=線上客服 href="#">線上客服</A> </P>
</DIV>
      </DIV>
    </DIV>
  </DIV>
</DIV>
<DIV id=footer>
		<P>
	  <a href="content.php?id=14" >關於我們</a>
  ┊	  <a href="content.php?id=15" >聯系我們</a>
  ┊	  <a href="content.php?id=16" >家長監護</a>
  ┊	  <a href="content.php?id=17" >糾紛處理</a>
  	  </P>
	  
  <P>
  Copyright 2016-2018 LT Markets Game All rights reserved 
  </P>
</DIV>
</body>
</html>
