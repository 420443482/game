<?php exit;?>a:3:{s:8:"template";a:11:{i:0;s:55:"/www/wwwroot/lushuihe.com.cn/templates/kele/index1.html";i:1;s:61:"/www/wwwroot/lushuihe.com.cn/templates/kele/index_header.html";i:2;s:64:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_game_slide.html";i:3;s:59:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_login.html";i:4;s:63:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_game_best.html";i:5;s:62:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_game_new.html";i:6;s:61:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_service.html";i:7;s:62:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_game_hot.html";i:8;s:58:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_news.html";i:9;s:58:"/www/wwwroot/lushuihe.com.cn/templates/kele/part_link.html";i:10;s:55:"/www/wwwroot/lushuihe.com.cn/templates/kele/footer.html";}s:7:"expires";i:1544197692;s:8:"maketime";i:1544194092;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>LT一站式遊戲充值平台.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="遊戲,充值" />
<meta name="description" content="LT遊戲充值平台" />
<LINK href="/templates/kele/img/reset.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/index_common.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/home.css" type=text/css rel=stylesheet>
<!--[if lte IE 6]>
<script src="/templates/kele/img/fixPNG.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('.pngfix');
</script>
<![endif]-->
<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript" src="scripts/function.js"></script>
</head>
<body>
<DIV id=header>
  <DIV class=top>
    <IMG class=pngfix id=logo src="/templates/kele/img/logo.png">
    <UL class="q_nav fr">
      <LI>
        <P class=fl><A class="icon i_reg" title=註冊 href="reg.php">註冊</A> <A class="icon i_log" title=登錄 href="login.php">登錄</A> <A class="icon i_pay" title=帳戶充值 href="pay.php">帳戶充值</A> </P>
        <P class=fr><A title=中文繁體 href="/">中文繁體</A>| <A title=ENGLISH href="en_index.php">ENGLISH</A></P>
      </LI>
    </UL>
  </DIV>
  <UL id=nav>
    <LI class=menu>
    	    	    		<A class="spe" href="/" >首頁</A>
    	    		<A class="spe" href="game.php" >遊戲中心</A>
    	    		<A class="spe" href="news.php" >遊戲動態</A>
    	    		<A class="spe" href="pay.php" >充值中心</A>
    	    		<A class="spe" href="card.php" >新手禮包</A>
    	    	    </LI>
    <LI class=s_msg style="display:none">
      <P class="fl icon i_laba">您好！如果您在遊戲過程中遇到任何問題，可以諮詢我們的線上客服幫您解決。</P>
      <P class=fr></P>
    </LI>
  </UL>
</DIV>
<div id="lunbo" style="z-index:-99;margin-top:-90px">
<link rel="stylesheet" type="text/css" href="templates/kele/css/demo-style.css">
<script type="text/javascript" src="templates/kele/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="templates/kele/js/banner.js"></script>
		<div id="xc" class="containerflash " style="z-index:-1">
		<div id="featured"> 	
<img src="templates/kele/images/q1.jpg"  style="z-index: 1; display: none;">
<img src="templates/kele/images/q2.jpg"  style="z-index: 2; display: none;">
<img src="templates/kele/images/q3.jpg"  style="z-index: 3; display: block;">
				  <div class="num">
                            <p class="lc"></p>
                            <p class="mc" id="numinner"><span class=""></span><span class=""></span><span class="on"></span>   </p>
                            <p class="rc"></p>
          </div>
		  </div>
	</div>
</div>
<div id="main_index" style="margin-top:-200px; z-index:999">
    
<DIV class="con clearfix">
  <DIV class=fl id=banner>
	<div id="imgShow" class="margin">
  <div class="banner_t">
      <ul>
	            <li><a href="game.php?action=server_list&game_id=3"><img src="uploads/20120322175112_bbqgyd.jpg"></a></li>
                <li><a href="game.php?action=server_list&game_id=2"><img src="uploads/20120322175044_sbdqbb.jpg"></a></li>
                <li><a href="game.php?action=server_list&game_id=1"><img src="uploads/20120322175014_cqfpxe.jpg"></a></li>
      	  </ul>
  </div>
  <div class="banner_b">
    <ul class="clearfix">
	   	   <li onclick="showImg(0);" class="">
          <a href="javascript:void(0);">
            <img src="uploads/20120322175112_lhjarl.jpg" width="64" height="33">
          </a>
          <div>
            <strong>誅神</strong>
            <a href="game.php?action=server_list&game_id=3"><span>新服開啟</span></a>
            <a href="pay.php?action=server_list&game_id=3" target="_blank">充值</a>
            <a href="card.php?game_id=3" target="_blank">新手卡</a>
          </div>
       </li>
	   	   <li onclick="showImg(1);" class="">
          <a href="javascript:void(0);">
            <img src="uploads/20120322175044_wtlzdf.jpg" width="64" height="33">
          </a>
          <div>
            <strong>傲劍</strong>
            <a href="game.php?action=server_list&game_id=2"><span>新服開啟</span></a>
            <a href="pay.php?action=server_list&game_id=2" target="_blank">充值</a>
            <a href="card.php?game_id=2" target="_blank">新手卡</a>
          </div>
       </li>
	   	   <li onclick="showImg(2);" class="">
          <a href="javascript:void(0);">
            <img src="uploads/20120322175014_ggigmp.jpg" width="64" height="33">
          </a>
          <div>
            <strong>仙域</strong>
            <a href="game.php?action=server_list&game_id=1"><span>新服開啟</span></a>
            <a href="pay.php?action=server_list&game_id=1" target="_blank">充值</a>
            <a href="card.php?game_id=1" target="_blank">新手卡</a>
          </div>
       </li>
	       </ul>
  </div>
</div>
<script type="text/javascript" src="/templates/kele/img/filmslide.js"></script>
  </DIV>
  <DIV class=fr id=uc_box>
	<div id="Tab1">
  <form id="login_form" name="login_form" method="post" action="user.php?action=login_ok">
  <DIV class=login_b>
  <H3 class=hid>用戶登錄</H3>
  <DIV class="i clearfix">
    <LABEL class=fl for=txtUserName>用戶名：</LABEL>
    <P class=fl>
      <input id="member_username" name="member_username" type="text" />
    </P>
  </DIV>
  <DIV class="i clearfix">
    <LABEL class=fl for=txtPwd>密&nbsp;&nbsp;碼：</LABEL>
    <P class=fl>
      <input id="member_password" name="member_password" type="password" />
    </P>
  </DIV>
  <DIV class=b>
	<input id="login_submit" type="button" value="" class="hid cur" />
	<input name="post_mode" type="hidden" value="withtml5">
    <P>
      <input id="keeplive" type="checkbox" value="" checked="checked">
      <LABEL for=keeplive>記住登錄帳號</LABEL>
      <A title=找回密碼 href="user.php?action=forget">找回密碼</A> </P>
  </DIV>
  <DIV class=b2><A class=hid href="reg.php">註冊</A></DIV>
  </DIV>
  </form>
</div>
<script type="text/javascript">
	var logins=function(){
		var member_username=$('#member_username').val();
		var member_password=$('#member_password').val();
		if ($.trim(member_username)==''){
			alert('用戶名不能為空！');
			return false;
		}
		if ($.trim(member_password)==''){
			alert('密碼不能為空！');
			return false;
		}
		if (member_password.length<6&&member_password.length>20){
			alert('密碼由6-20個字元組成，建議使用英文字母加數位或符號的組合密碼。');
			return false;
		}
		
		$("#login_form").submit();
	};
	$("#login_submit").click(function(){
		logins();
	});
</script>
<div id="Tab2" style="display:none;">
<div class="login_a">
    <h3 class="hid">用戶登錄</h3>
    <div class="info">
        <img alt="avata" src="/templates/kele/img/avata.jpg">
        <dl>
            <dt><strong>歡迎登錄遊戲平臺！</strong></dt>
                <dd class="u_name"></dd>
        </dl>
    </div>
    <div class="b t_c">
        <a title="遊戲中心" href="game.php">遊戲中心</a>
        <a title="用戶中心" href="user.php">用戶中心</a>
        <a title="立即充值" href="pay.php">立即充值</a>
        <a title="禮包領取" href="card.php">禮包領取</a>
    </div>
    <div class="b2 t_c">
        <a title="安全退出" href="user.php?action=logout">安全退出</a>
    </div>
</div>
</div>
<script type="text/javascript">
var login_state=4f62c4718c80e165225fget_login_state|a:1:{s:4:"name";s:15:"get_login_state";}4f62c4718c80e165225f;
if(login_state==1){
	$("#Tab1").hide();
	$("#Tab2").show();
}
</script>
  </DIV>
</DIV>
<DIV class="h_hot_game clearfix">
<div class="h_hot_div">
  <a href="game.php?action=server_list&game_id=56"><img class="pngfix" src="uploads/20180809124155_izmbut.png"></a>
  <p>
      <a title="充值" href="pay.php?game_id=56" target="_blank">充值</a>
      <a title="新手卡" href="card.php?game_id=56">新手卡</a>
      <a class="a3" title="進入遊戲" href="game.php?action=server_list&game_id=56">進入遊戲</a>
  </p>
</div>
<div class="h_hot_div">
  <a href="game.php?action=server_list&game_id=55"><img class="pngfix" src="uploads/20180809123947_uuvvto.png"></a>
  <p>
      <a title="充值" href="pay.php?game_id=55" target="_blank">充值</a>
      <a title="新手卡" href="card.php?game_id=55">新手卡</a>
      <a class="a3" title="進入遊戲" href="game.php?action=server_list&game_id=55">進入遊戲</a>
  </p>
</div>
<div class="h_hot_div">
  <a href="game.php?action=server_list&game_id=54"><img class="pngfix" src="uploads/20180809124111_qqtped.png"></a>
  <p>
      <a title="充值" href="pay.php?game_id=54" target="_blank">充值</a>
      <a title="新手卡" href="card.php?game_id=54">新手卡</a>
      <a class="a3" title="進入遊戲" href="game.php?action=server_list&game_id=54">進入遊戲</a>
  </p>
</div>
<div class="h_hot_div">
  <a href="game.php?action=server_list&game_id=53"><img class="pngfix" src="uploads/20180809124915_hagogd.png"></a>
  <p>
      <a title="充值" href="pay.php?game_id=53" target="_blank">充值</a>
      <a title="新手卡" href="card.php?game_id=53">新手卡</a>
      <a class="a3" title="進入遊戲" href="game.php?action=server_list&game_id=53">進入遊戲</a>
  </p>
</div>
</DIV>
<DIV class="con clearfix" style="ZOOM: 1">
  <DIV class="col1 fl">
    <DIV class="box zxkf">
      <H3><STRONG class=fl>最新开服</STRONG> </H3>
      <DIV class=margin>
        <div class="zxkf_div"><img class="fl" src="uploads/20180809123010_othqyg.jpg">
  <p class="fl"><a class="btn_green" title="進入遊戲" href="game.php?action=server_list&game_id=39">進入遊戲</a>
  <a class="btn_gray" title="領取禮包" href="card.php?game_id=39">領取禮包</a></p>
</div>
<div class="intro"><strong>雙線204服 2018-08-08 14點</strong>
<p></p>
</div>
      </DIV>
    </DIV>
    <DIV class="box cs">
      <DIV class=margin>
        <DIV class=cs_div>
          <H4 class=hid>客服中心</H4>
          <P>技術T E L：+8617620373555 </P>
          <P>在線郵箱：<a target="_blank" href="mailto:davejason702@gmail.com">davejason702@gmail.com</a> </P>
          <P><A class=c1 title=帳號申訴 href="#"><SPAN>帳號申訴</SPAN></A> <A class=c2 title=線上客服 href="#">線上客服</A> </P>
</DIV>
      </DIV>
    </DIV>
  </DIV>
  <DIV class="box yxtj fl">
    <H3><STRONG class=fl>火爆游戏</STRONG> <A class=fr title=更多 href="game.php">更多&gt;&gt;</A> </H3>
    <DIV class=margin>
    	<div class="g_link clearfix">
    <a href="game.php?action=server_list&game_id=2"><img src="uploads/20120308181044_klpsta.jpg" class="fl"></a>
    <p class="fl">
        <a target="_blank" title="進入遊戲" href="game.php?action=server_list&game_id=2">進入遊戲</a>
        <a target="_blank" title="玩家充值" href="pay.php?game_id=2">玩家充值</a>
        <a title="領取禮包" href="card.php?game_id=2">領取禮包</a>
        <a title="進入遊戲" href="game.php?action=server_list&game_id=2" class="l4"><span>進入遊戲</span></a>
    </p>
</div>
<div class="g_intro clearfix">
    <p>《傲劍》是款斥資六千萬天價全程自主研發的ARPG武俠無端網遊，傲劍其華麗暢爽的即時戰鬥畫面、強絕的武學秘籍系統、多線交錯的豐富劇情、結合創新領先的技術引擎以及最佳網絡問題解決方案，傲劍讓您時時感受.....</p>
</div>
<div class="g_snap">
    <h5><strong>遊戲截圖</strong></h5>
    <ul>
        <li>
            <img src="uploads/20120322175044_dtpvor.jpg">
        </li>
         <li>
            <img src="uploads/20120322175044_pcfqbx.jpg">
        </li>
        <li>
            <img src="uploads/20120322175044_wtlsba.jpg">
        </li>
        <li>
            <img src="uploads/20120322175044_rxcajz.jpg">
        </li>
    </ul>
</div>
    </DIV>
  </DIV>
  <DIV class="col2 fr clearfix">
    <DIV class="box latest_news">
      <H3><STRONG class=fl>游戏动态</STRONG> <A class=fr title=更多 href="news.php">更多&gt;&gt;</A> </H3>
      <DIV class=margin>
        <ul class="list">
<li><a title="益智遊戲泡泡龍被改編網遊 韓國G..." href="content.php?id=21">益智遊戲泡泡龍被改編網遊 韓國G...</a> </li>
<li><a title="Nexon格鬥新作《Zone4》..." href="content.php?id=20">Nexon格鬥新作《Zone4》...</a> </li>
<li><a title="《大皇帝》遊族花唄開通公告" href="content.php?id=19">《大皇帝》遊族花唄開通公告</a> </li>
<li><a title="《三十六計》手遊 限號精英測試正..." href="content.php?id=18">《三十六計》手遊 限號精英測試正...</a> </li>
</ul>      </DIV>
    </DIV>
    <DIV class="box getgift clearfix">
      <DIV class=margin><A href="card.php"><IMG src="/templates/kele/img/getgift.png"></A> </DIV>
    </DIV>
  </DIV>
</DIV>
<div class="box friendlink">
    <h3>
        <strong class="fl">友情链接</strong>
    </h3>
    <div class="margin">
        <ul class="clearfix">
            <li>
						<a href="http://www.gk86.com" target="_blank" title="">廣庫網絡</a>
						<a href="http://game.163.com/" target="_blank" title="">網易遊戲</a>
						<a href="http://game.qq.com" target="_blank" title="">騰訊遊戲</a>
						</li>
        </ul>
    </div>
</div>
<DIV id=footer>
		<P>
	  <a href="content.php?id=14" >關於我們</a>
  ┊	  <a href="content.php?id=15" >聯系我們</a>
  ┊	  <a href="content.php?id=16" >家長監護</a>
  ┊	  <a href="content.php?id=17" >糾紛處理</a>
  	  </P>
	  
  <P>
  Copyright 2016-2018 LT Markets Game All rights reserved 
  </P>
</DIV>
</body>
</html>
