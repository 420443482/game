<?php exit;?>a:3:{s:8:"template";a:6:{i:0;s:56:"/www/wwwroot/lushuihe.com.cn/templates/kele/en_game.html";i:1;s:58:"/www/wwwroot/lushuihe.com.cn/templates/kele/en_header.html";i:2;s:62:"/www/wwwroot/lushuihe.com.cn/templates/kele/en_part_login.html";i:3;s:60:"/www/wwwroot/lushuihe.com.cn/templates/kele/en_part_faq.html";i:4;s:64:"/www/wwwroot/lushuihe.com.cn/templates/kele/en_part_service.html";i:5;s:58:"/www/wwwroot/lushuihe.com.cn/templates/kele/en_footer.html";}s:7:"expires";i:1544169488;s:8:"maketime";i:1544165888;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>LT一站式遊戲充值平台.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="遊戲,充值" />
<meta name="description" content="LT遊戲充值平台" />
<LINK href="/templates/kele/img/reset.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/en_common.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/en_gamelist.css" type=text/css rel=stylesheet>
<!--[if lte IE 6]>
<script src="/templates/kele/img/fixPNG.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('.pngfix');
</script>
<![endif]--> 
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<DIV id=header>
  <DIV class=top>
    <IMG class=pngfix id=logo src="/templates/kele/img/logo.png">
    <UL class="q_nav fr">
      <LI>
        <P class=fl><A class="icon i_reg" title=Register href="en_reg.php">Register</A> <A class="icon i_log" title=LOGIN href="en_login.php">Login</A> <A class="icon i_pay" title="Account recharge" href="en_pay.php">recharge</A> </P>
        <P class=fr><A title=中文繁體 href="/">中文繁體</A>| <A title=ENGLISH href="en_index.php">ENGLISH</A></P>
      </LI>
    </UL>
  </DIV>
  <UL id=nav>
    <LI class=menu>
    	    	    		<A class="spe" href="en_index.php" >Home</A>
    	    		<A class="spe" href="en_game.php" >Game</A>
    	    		<A class="spe" href="en_news.php" >News</A>
    	    		<A class="spe" href="en_pay.php" >Recharge</A>
    	    		<A class="spe" href="en_content.php?id=14" >About</A>
    	    	    </LI>
    <LI class=s_msg>
      <P class="fl icon i_laba">Hello! If you encounter any problems in the game, you can consult our online customer service to help you solve it.</P>
      <P class=fr></P>
    </LI>
  </UL>
</DIV>
 
<DIV class="mainContent clearfix">
  <DIV class="left box game_center">
    <h3 class="gl"><strong class="fl pngfix hid">Game center</strong></h3>
    <DIV class=margin>
<ul class="g_list clearfix">
<li><a href="en_game.php?action=server_list&game_id=56"><img class="fl" src="uploads/20180808161805_ifsktn.jpg"></a>
  <div class="fl">
    <p><strong>KTZS</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=56">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=55"><img class="fl" src="uploads/20180808161739_vegpnt.jpg"></a>
  <div class="fl">
    <p><strong>CYCS2</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=55">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=54"><img class="fl" src="uploads/20180808161718_ipaqbl.jpg"></a>
  <div class="fl">
    <p><strong>TJKD</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=54">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=53"><img class="fl" src="uploads/20180808161646_yfftjw.jpg"></a>
  <div class="fl">
    <p><strong>HMZL</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=53">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=52"><img class="fl" src="uploads/20180808161622_jjqjdg.jpg"></a>
  <div class="fl">
    <p><strong>RXSG2</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=52">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=51"><img class="fl" src="uploads/20180808161558_ndwaok.jpg"></a>
  <div class="fl">
    <p><strong>DMZT</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=51">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=50"><img class="fl" src="uploads/20180808161536_juoivc.jpg"></a>
  <div class="fl">
    <p><strong>DLDL</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=50">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=49"><img class="fl" src="uploads/20180808161511_trqbuz.jpg"></a>
  <div class="fl">
    <p><strong>BBZJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=49">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=48"><img class="fl" src="uploads/20180808161453_oobgqw.jpg"></a>
  <div class="fl">
    <p><strong>XQJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=48">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=47"><img class="fl" src="uploads/20180808161431_csqrik.jpg"></a>
  <div class="fl">
    <p><strong>HHZZ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=47">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=46"><img class="fl" src="uploads/20180808161408_adqmth.jpg"></a>
  <div class="fl">
    <p><strong>LYCQ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=46">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=45"><img class="fl" src="uploads/20180808161346_vxjhbs.jpg"></a>
  <div class="fl">
    <p><strong>FTJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=45">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=44"><img class="fl" src="uploads/20180808161324_fkdhoj.jpg"></a>
  <div class="fl">
    <p><strong>ZT</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=44">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=43"><img class="fl" src="uploads/20180808161305_ivzdcn.jpg"></a>
  <div class="fl">
    <p><strong>HDX</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=43">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=42"><img class="fl" src="uploads/20180808161238_fbugad.jpg"></a>
  <div class="fl">
    <p><strong>QQCS</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=42">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=41"><img class="fl" src="uploads/20180808161208_tebtgp.jpg"></a>
  <div class="fl">
    <p><strong>SS</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=41">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=40"><img class="fl" src="uploads/20180808161140_yrkhiq.jpg"></a>
  <div class="fl">
    <p><strong>XMRY</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=40">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=39"><img class="fl" src="uploads/20180808161112_sbxpvm.jpg"></a>
  <div class="fl">
    <p><strong>DHD</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=39">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=38"><img class="fl" src="uploads/20180808161051_owhvho.jpg"></a>
  <div class="fl">
    <p><strong>TJJQ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=38">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=37"><img class="fl" src="uploads/20180808004803_fxusdy.jpg"></a>
  <div class="fl">
    <p><strong>FBYX</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=37">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=36"><img class="fl" src="uploads/20180808004739_sdpxge.jpg"></a>
  <div class="fl">
    <p><strong>NZ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=36">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=35"><img class="fl" src="uploads/20180808004717_qzlmmg.jpg"></a>
  <div class="fl">
    <p><strong>ZX</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=35">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=34"><img class="fl" src="uploads/20180808004656_wmbwyh.jpg"></a>
  <div class="fl">
    <p><strong>LZG</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=34">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=33"><img class="fl" src="uploads/20180808004629_eukgfo.jpg"></a>
  <div class="fl">
    <p><strong>CQ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=33">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=32"><img class="fl" src="uploads/20180808004607_syyctx.jpg"></a>
  <div class="fl">
    <p><strong>TJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=32">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=31"><img class="fl" src="uploads/20180808004546_fvbsam.jpg"></a>
  <div class="fl">
    <p><strong>SMSJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=31">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=30"><img class="fl" src="uploads/20180808004521_dhmnav.jpg"></a>
  <div class="fl">
    <p><strong>JDQSDTS</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=30">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=29"><img class="fl" src="uploads/20180808004448_ermiza.jpg"></a>
  <div class="fl">
    <p><strong>LFZL</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=29">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=28"><img class="fl" src="uploads/20180808004425_jutfmz.jpg"></a>
  <div class="fl">
    <p><strong>HSSM</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=28">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=27"><img class="fl" src="uploads/20180808004400_dqanfj.jpg"></a>
  <div class="fl">
    <p><strong>MXD</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=27">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=26"><img class="fl" src="uploads/20180808004320_gxeouz.jpg"></a>
  <div class="fl">
    <p><strong>TT</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=26">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=25"><img class="fl" src="uploads/20180808004253_igoyav.jpg"></a>
  <div class="fl">
    <p><strong>AEZG</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=25">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=24"><img class="fl" src="uploads/20180808004225_qkmmmj.jpg"></a>
  <div class="fl">
    <p><strong>DXCYYS</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=24">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=23"><img class="fl" src="uploads/20180808004145_uizfau.jpg"></a>
  <div class="fl">
    <p><strong>QHYX</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=23">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=22"><img class="fl" src="uploads/20180808004121_hjruqe.jpg"></a>
  <div class="fl">
    <p><strong>CSGO</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=22">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=21"><img class="fl" src="uploads/20180808004057_hjnalx.jpg"></a>
  <div class="fl">
    <p><strong>BXJG</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=21">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=20"><img class="fl" src="uploads/20180808004025_snjnye.jpg"></a>
  <div class="fl">
    <p><strong>CYHX2</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=20">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=19"><img class="fl" src="uploads/20180808004000_oqydka.jpg"></a>
  <div class="fl">
    <p><strong>LSQY</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=19">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=18"><img class="fl" src="uploads/20180808003937_qdxdlw.jpg"></a>
  <div class="fl">
    <p><strong>XTLBB</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=18">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=17"><img class="fl" src="uploads/20180808003907_fcqwpf.jpg"></a>
  <div class="fl">
    <p><strong>TKSJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=17">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=16"><img class="fl" src="uploads/20180808003835_usoqby.jpg"></a>
  <div class="fl">
    <p><strong>LSCS</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=16">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=15"><img class="fl" src="uploads/20180808003806_ddxoid.jpg"></a>
  <div class="fl">
    <p><strong>MHXY</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=15">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=14"><img class="fl" src="uploads/20180808003735_kjnrxd.jpg"></a>
  <div class="fl">
    <p><strong>CQBY</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=14">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=13"><img class="fl" src="uploads/20180808003709_nylonp.jpg"></a>
  <div class="fl">
    <p><strong>MSSJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=13">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=12"><img class="fl" src="uploads/20180808003635_atvtnw.jpg"></a>
  <div class="fl">
    <p><strong>DOTA2</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=12">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=11"><img class="fl" src="uploads/20180808003602_asqhek.jpg"></a>
  <div class="fl">
    <p><strong>WDSJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=11">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=10"><img class="fl" src="uploads/20180808003534_xbfwmi.jpg"></a>
  <div class="fl">
    <p><strong>JYZJ2</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=10">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=9"><img class="fl" src="uploads/20180808003500_wevhsl.jpg"></a>
  <div class="fl">
    <p><strong>CSZC</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=9">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=8"><img class="fl" src="uploads/20180808003358_vcrmff.jpg"></a>
  <div class="fl">
    <p><strong>SWXF</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=8">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=7"><img class="fl" src="uploads/20120314214107_tvbbnu.jpg"></a>
  <div class="fl">
    <p><strong>SXD</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=7">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=6"><img class="fl" src="uploads/20120314122959_wclnct.jpg"></a>
  <div class="fl">
    <p><strong>LJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=6">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=5"><img class="fl" src="uploads/20120314122710_hjheqj.jpg"></a>
  <div class="fl">
    <p><strong>SSSG</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=5">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=4"><img class="fl" src="uploads/20120308180959_wasmqu.jpg"></a>
  <div class="fl">
    <p><strong>FRXZ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=4">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=3"><img class="fl" src="uploads/20120308180923_jkopnr.jpg"></a>
  <div class="fl">
    <p><strong>ZS</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=3">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=2"><img class="fl" src="uploads/20120308180839_aiiylr.jpg"></a>
  <div class="fl">
    <p><strong>AJ</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=2">Recharge</a></p>
  </div>
</li>
<li><a href="en_game.php?action=server_list&game_id=1"><img class="fl" src="uploads/20120308180433_xozmnn.jpg"></a>
  <div class="fl">
    <p><strong>XY</strong><br>
      <a class="a1" >online Game</a><br>
	  <a class="a2"  target="_blank">Hots Game</a>  </p>
    <p><a class="a4 hid" href="en_pay.php?game_id=1">Recharge</a></p>
  </div>
</li>
</ul>
    </DIV>
  </DIV>
  <DIV class=sidebar>
    <DIV class="" id=uc_box>
      <div id="Tab1">
  <form id="login_form" name="login_form" method="post" action="user.php?action=login_ok">
  <DIV class=login_b>
  <H3 class=hid>User login</H3>
  <DIV class="i clearfix">
    <LABEL class=fl for=txtUserName>Username：</LABEL>
    <P class=fl>
      <input id="member_username" name="member_username" type="text" />
    </P>
  </DIV>
  <DIV class="i clearfix">
    <LABEL class=fl for=txtPwd>Password：</LABEL>
    <P class=fl>
      <input id="member_password" name="member_password" type="password" />
    </P>
  </DIV>
  <DIV class=b>
	<input id="login_submit" type="button" value="" class="hid cur" />
	<input name="post_mode" type="hidden" value="withtml5">
    <P>
      <input id="keeplive" type="checkbox" value="" checked="checked">
      <LABEL for=keeplive>Remember account</LABEL>
      <A title="Retrieve the password" href="en_user.php?action=forget">Retrieve the password</A> </P>
  </DIV>
  <DIV class=b2><A class=hid href="en_reg.php">Register</A></DIV>
  </DIV>
  </form>
</div>
<script type="text/javascript">
	var logins=function(){
		var member_username=$('#member_username').val();
		var member_password=$('#member_password').val();
		if ($.trim(member_username)==''){
			alert('用戶名不能為空！');
			return false;
		}
		if ($.trim(member_password)==''){
			alert('密碼不能為空！');
			return false;
		}
		if (member_password.length<6&&member_password.length>20){
			alert('密碼由6-20個字元組成，建議使用英文字母加數位或符號的組合密碼。');
			return false;
		}
		
		$("#login_form").submit();
	};
	$("#login_submit").click(function(){
		logins();
	});
</script>
<div id="Tab2" style="display:none;">
<div class="login_a">
    <h3 class="hid">User login</h3>
    <div class="info">
        <img alt="avata" src="/templates/kele/img/avata.jpg">
        <dl>
            <dt><strong>Welcome to the game platform!</strong></dt>
                <dd class="u_name"></dd>
        </dl>
    </div>
    <div class="b t_c">
        <a title="Game center" href="en_game.php">Game</a>
        <a title="User center" href="en_user.php">center</a>
        <a title="recharge" href="en_pay.php">Recharge</a>
        <a title="Receive gifts" href="en_user.php?action=card" >MYGifts</a>
    </div>
    <div class="b2 t_c">
        <a title="safe out" href="en_user.php?action=logout">Safe out</a>
    </div>
</div>
</div>
<script type="text/javascript">
var login_state=4f62c4718c80e165225fget_login_state|a:1:{s:4:"name";s:15:"get_login_state";}4f62c4718c80e165225f;
if(login_state==1){
	$("#Tab1").hide();
	$("#Tab2").show();
}
</script>
    </DIV>
    <DIV class="box latest_news">
      <h3><strong class="fl pngfix">Common problems</strong> <a title="More" href="en_news.php?id=2" class="fr">More&gt;&gt;</a></h3>
<DIV class=margin>
<ul class="list">
<li><a title="How is the account stolen" href="en_content.php?id=9">How is the account stolen</a> </li>
<li><a title="How to forget the password" href="en_content.php?id=8">How to forget the password</a> </li>
</ul>
</DIV>
    </DIV>
    <DIV class="box cs">
      <DIV class=margin>
      	<DIV class=cs_div>
          <H4 class=hid>Service center</H4>
          <P>Service Tel：+8617620373555 </P>
          <P>Service email：<a target="_blank" href="mailto:davejason702@gmail.com">davejason702@gmail.com</a> </P>
          <P><A class=c1 title="Account claim" claim href="#"><SPAN>Account claim</SPAN></A> <A class=c2 title="Online customer service" href="#">Online customer service</A> </P>
</DIV>
      </DIV>
    </DIV>
  </DIV>
</DIV>
<DIV id=footer>
		<P>
	  <a href="en_content.php?id=14" >About </a>
  ┊	  <a href="en_content.php?id=15" >contactus </a>
  ┊	  <a href="en_content.php?id=16" >Guardianship </a>
  ┊	  <a href="en_content.php?id=17" >Dispute handling </a>
  	  </P>
	  
  <P>
  Copyright 2016-2018 LT Markets Game All rights reserved 
  </P>
</DIV></body>
</html>
