<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_var['config']['site_name']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php echo htmlspecialchars($this->_var['config']['site_keywords']); ?>" />
<meta name="description" content="<?php echo htmlspecialchars($this->_var['config']['site_description']); ?>" />
<LINK href="/templates/kele/img/reset.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/en_common.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/news.css" type=text/css rel=stylesheet>
<!--[if lte IE 6]>
<script src="/templates/kele/img/fixPNG.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('.pngfix');
</script>
<![endif]--> 
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<?php echo $this->fetch('en_header.html'); ?>
 
<DIV class="mainContent clearfix">
  <div class="left box newlist">
     <h3><strong class="fl icon_07"><?php if ($this->_var['channel_info']['name'] == '關於我們'): ?>About<?php elseif ($this->_var['channel_info']['name'] == '聯繫我們'): ?>Contact us<?php elseif ($this->_var['channel_info']['name'] == '家長監護'): ?>Guardianship of parents<?php elseif ($this->_var['channel_info']['name'] == '糾紛處理'): ?>Dispute handling<?php else: ?><?php echo $this->_var['channel_info']['name']; ?><?php endif; ?></strong></h3>
    <DIV class=margin>
    	<DIV class=last_content>
			  <H2><?php echo $this->_var['content_info']['title_en']; ?></H2>
			  <DIV class=line><?php echo $this->_var['content_info']['text_en']; ?></DIV>
			  <hr size="1" style="border:1px dotted #AAA; width:98%;">
			  <div style="padding-left:10px;">
<?php if ($this->_var['prev'] != ''): ?>
<div>The last one：
<a href="en_<?php echo $this->_var['prev']['url']; ?>" <?php if ($this->_var['content']['target']): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['prev']['title_en']; ?></a>
</div>
<?php endif; ?>
<?php if ($this->_var['next'] != ''): ?>
<div>
Next one：
<a href="en_<?php echo $this->_var['next']['url']; ?>" <?php if ($this->_var['content']['target']): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['next']['title_en']; ?></a>
</div>
<?php endif; ?>
			  </div>
			</DIV>
    </DIV>
  </DIV>
  <DIV class=sidebar>
    <DIV class="" id=uc_box>
      <?php echo $this->fetch('en_part_login.html'); ?>
    </DIV>
    <DIV class="box latest_news">
      <?php echo $this->fetch('en_part_faq.html'); ?>
    </DIV>
    <DIV class="box cs">
      <DIV class=margin>
      	<?php echo $this->fetch('en_part_service.html'); ?>
      </DIV>
    </DIV>
  </DIV>
</DIV>

<?php echo $this->fetch('en_footer.html'); ?>
</body>
</html>
