<DIV class=cs_div>
          <H4 class=hid>Service center</H4>
          <P>Service Tel：+8617620373555 </P>
          <P>Service email：<a target="_blank" href="mailto:davejason702@gmail.com">davejason702@gmail.com</a> </P>
          <P><A class=c1 title="Account claim" claim href="#"><SPAN>Account claim</SPAN></A> <A class=c2 title="Online customer service" href="#">Online customer service</A> </P>
</DIV>
