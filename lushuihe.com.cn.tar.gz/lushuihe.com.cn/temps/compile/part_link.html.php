<?php if ($this->_var['link']): ?>
<div class="box friendlink">
    <h3>
        <strong class="fl">友情链接</strong>
    </h3>
    <div class="margin">
        <ul class="clearfix">
            <li>
			<?php $_from = $this->_var['link']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link_0_11502200_1543045926');if (count($_from)):
    foreach ($_from AS $this->_var['link_0_11502200_1543045926']):
?>
			<a href="<?php echo $this->_var['link_0_11502200_1543045926']['url']; ?>" target="_blank" title="<?php echo $this->_var['link_0_11502200_1543045926']['text']; ?>"><?php echo $this->_var['link_0_11502200_1543045926']['name']; ?></a>
			<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
			</li>
        </ul>
    </div>
</div>
<?php endif; ?>
