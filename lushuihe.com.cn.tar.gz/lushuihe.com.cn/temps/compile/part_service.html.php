<DIV class=cs_div>
          <H4 class=hid>客服中心</H4>
          <P>技術T E L：+8617620373555 </P>
          <P>在線郵箱：<a target="_blank" href="mailto:davejason702@gmail.com">davejason702@gmail.com</a> </P>
          <P><A class=c1 title=帳號申訴 href="#"><SPAN>帳號申訴</SPAN></A> <A class=c2 title=線上客服 href="#">線上客服</A> </P>
</DIV>
