<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_var['config']['site_name']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php echo htmlspecialchars($this->_var['config']['site_keywords']); ?>" />
<meta name="description" content="<?php echo htmlspecialchars($this->_var['config']['site_description']); ?>" />
<LINK href="/templates/kele/img/reset.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/common.css" type=text/css rel=stylesheet>
<LINK href="/templates/kele/img/gamelist.css" type=text/css rel=stylesheet>
<!--[if lte IE 6]>
<script src="/templates/kele/img/fixPNG.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('.pngfix');
</script>
<![endif]--> 
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<?php echo $this->fetch('header.html'); ?>
 
<DIV class="mainContent clearfix">
  <div class="left box uc">
	<h3>
		<strong class="fl icon_06">新手禮包</strong>
	</h3>
    <div class=margin>
		<div class="recommend_list">
		  <p><strong><span id="lblGameTitle"><?php echo $this->_var['game_name']; ?></span>新手禮包</strong></p>
		</div>
		<?php if ($this->_var['card_list']): ?>
		<div class="xsk_content">
			<h2>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center">名稱</td>
                <td width="15%" align="center">數量</td>
                <td width="15%" align="center">剩餘</td>
                <td width="15%" align="center">限制</td>
                <td width="20%" align="center">領取</td>
              </tr>
            </table>
			</h2>
			<ul>
				<?php $_from = $this->_var['card_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'card');if (count($_from)):
    foreach ($_from AS $this->_var['card']):
?>
				<li>
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
					  <tr>
						<td align="center"><?php echo $this->_var['card']['name']; ?></td>
						<td width="15%" align="center"><?php echo $this->_var['card']['count']; ?></td>
						<td width="15%" align="center"><?php echo $this->_var['card']['frees']; ?></td>
						<td width="15%" align="center">無限制</td>
						<td width="20%" align="center">
						<?php if ($this->_var['card']['link'] != ''): ?>
							<a href="<?php echo $this->_var['card']['link']; ?>" target="_blank">我要領取</a>
						<?php else: ?>
							<?php if ($this->_var['card']['frees'] == 0): ?>
							發放結束
							<?php else: ?>
							<a href="card.php?action=get_card&id=<?php echo $this->_var['card']['id']; ?>"><img src="templates/kele/img/cd_btn2.gif" border="0" /></a>
							<?php endif; ?>
						<?php endif; ?>
						</td>
					  </tr>
				  </table>
				</li>
				<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
			</ul>
	  </div>
	  <?php endif; ?>
    </div>
  </div>
  <div class=sidebar>
    <div class="" id=uc_box>
      <?php echo $this->fetch('part_login.html'); ?>
    </div>
    <div class="box latest_news">
      <?php echo $this->fetch('part_faq.html'); ?>
    </div>
    <div class="box cs">
      <div class=margin>
      	<?php echo $this->fetch('part_service.html'); ?>
      </div>
    </div>
  </div>
</div>

<?php echo $this->fetch('footer.html'); ?>
</body>
</html>
