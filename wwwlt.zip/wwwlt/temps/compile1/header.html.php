<DIV id=header>
  <DIV class=top>
    <IMG class=pngfix id=logo src="/templates/kele/img/logo.png">
    <UL class="q_nav fr">
      <LI>
        <P class=fl><A class="icon i_reg" title=注册 href="reg.php">注册</A> <A class="icon i_log" title=登录 href="login.php">登录</A> <A class="icon i_pay" title=账户充值 href="pay.php">账户充值</A> </P>
        <P class=fr><A title=设为首页 href="javascript:void(0);">设为首页</A>| <A title=收藏本站 href="javascript:void(0);">收藏本站</A></P>
      </LI>
    </UL>
  </DIV>
  <UL id=nav>
    <LI class=menu>
    	<?php if ($this->_var['top_menu']): ?>
    	<?php $_from = $this->_var['top_menu']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'menu');if (count($_from)):
    foreach ($_from AS $this->_var['menu']):
?>
    		<A class="spe" href="<?php echo $this->_var['menu']['link']; ?>" <?php if ($this->_var['menu']['target'] == 1): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['menu']['name']; ?></A>
    	<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    	<?php endif; ?>
    </LI>
    <LI class=s_msg>
      <P class="fl icon i_laba">您好！如果您在游戏过程中遇到任何问题，可以咨询我们的在线客服帮您解决。</P>
      <P class=fr></P>
    </LI>
  </UL>
</DIV>
