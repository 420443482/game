<DIV class=cs_div>
          <H4 class=hid>客服中心</H4>
          <P>技术QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=314839&site=qq&menu=yes">314839</a> </P>
          <P>销售QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=89796949&site=qq&menu=yes">89796949</a> </P>
          <P><A class=c1 title=帐号申诉 href="#"><SPAN>帐号申诉</SPAN></A> <A class=c2 title=在线客服 href="#">在线客服</A> </P>
</DIV>