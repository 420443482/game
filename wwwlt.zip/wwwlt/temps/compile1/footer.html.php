<DIV id=footer>
	<?php if ($this->_var['bottom_menu']): ?>
	<P>
	<?php $_from = $this->_var['bottom_menu']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'menu_0_39724400_1533654980');$this->_foreach['bottom_menu'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['bottom_menu']['total'] > 0):
    foreach ($_from AS $this->_var['menu_0_39724400_1533654980']):
        $this->_foreach['bottom_menu']['iteration']++;
?>
  <a href="<?php echo $this->_var['menu_0_39724400_1533654980']['link']; ?>" <?php if ($this->_var['menu_0_39724400_1533654980']['target'] == 1): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['menu_0_39724400_1533654980']['name']; ?></a>
  <?php if (! ($this->_foreach['bottom_menu']['iteration'] == $this->_foreach['bottom_menu']['total'])): ?>┊<?php endif; ?>
	<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
  </P>
	<?php endif; ?>  
  <P>
  Copyright 2011 ctrlz.cn All rights reserved ┊ <?php echo $this->_var['config']['site_icp']; ?> ┊<script src="http://s21.cnzz.com/stat.php?id=3920679&web_id=3920679" language="JavaScript"></script>
  </P>
</DIV>
