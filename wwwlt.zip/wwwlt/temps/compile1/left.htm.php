<dl class='leftmenu'>
<dt><?php echo $this->_var['language']['menu_config']; ?></dt>
<dd><a href='?action=config&do=config'><?php echo $this->_var['language']['menu_config_1']; ?></a></dd>
<dd><a href='?action=config&do=menu_list'><?php echo $this->_var['language']['menu_config_2']; ?></a></dd>
<dd><a href='?action=config&do=admin_list'><?php echo $this->_var['language']['menu_config_3']; ?></a></dd>

<dt><?php echo $this->_var['language']['menu_content']; ?></dt>
<dd><a href='?action=content&do=channel_list'><?php echo $this->_var['language']['menu_content_4']; ?></a></dd>
<dd><a href='?action=game&do=game_list'><?php echo $this->_var['language']['menu_content_5']; ?></a></dd>
<dd><a href='?action=game&do=pay_list'><?php echo $this->_var['language']['menu_content_6']; ?></a></dd>
<dd><a href='?action=game&do=card_list'><?php echo $this->_var['language']['menu_content_7']; ?></a></dd>

<dt><?php echo $this->_var['language']['menu_member']; ?></dt>
<dd><a href='?action=member&do=member_list'><?php echo $this->_var['language']['menu_member_1']; ?></a></dd>

<dt>模板管理</dt>
<dd><a href='?action=template&do=template_list'>编辑模板</a></dd>

<dt><?php echo $this->_var['language']['menu_other']; ?></dt>
<dd><a href='?action=other&do=link_list'><?php echo $this->_var['language']['menu_other_3']; ?></a></dd>
<dd><a href='?action=game&do=sp_data'><?php echo $this->_var['language']['menu_other_4']; ?></a></dd>
</dl>
