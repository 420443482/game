<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="UTF-8">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $this->_var['language']['title']; ?></title>
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<?php echo $this->fetch('top.htm'); ?>
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
<td width="150" valign="top"><?php echo $this->fetch('left.htm'); ?></td>
<td valign="top">
	<div class='title'>&raquo;&nbsp;<?php echo $this->_var['language']['system_info']; ?></div>
	<div class='item'>
	<ul class='list'>
	<li><?php echo $this->_var['language']['system_info_1']; ?><?php echo $this->_var['system_info']['SERVER_TIME']; ?></li>
	<li  style="background:#efefef"><?php echo $this->_var['language']['system_info_2']; ?><?php echo $this->_var['system_info']['SERVER_PORT']; ?></li>
	<li><?php echo $this->_var['language']['system_info_3']; ?><a href='./' target="_blank" style="color:red;text-decoration:underline"><?php echo $this->_var['system_info']['SERVER_NAME']; ?></a></li>
	<li  style="background:#efefef"><?php echo $this->_var['language']['system_info_4']; ?><?php echo $this->_var['system_info']['PHP_OS']; ?></li>
	<li><?php echo $this->_var['language']['system_info_5']; ?><?php echo $this->_var['system_info']['SERVER_SOFTWARE']; ?></li>
	<li  style="background:#efefef"><?php echo $this->_var['language']['system_info_6']; ?>MYSQL <?php echo $this->_var['system_info']['DB_VERSION']; ?></li>
	<li><?php echo $this->_var['language']['system_info_7']; ?><?php echo $this->_var['system_info']['DOCUMENT_ROOT']; ?></li>
	<li  style="background:#efefef"><?php echo $this->_var['language']['system_info_8']; ?><?php echo $this->_var['system_info']['UPLOAD_MAX_FILESIZE']; ?></li>
	</ul>
	</div>
	
	<div class='title'>&raquo;&nbsp;技术支持</div>
	<div class='item'>
	<ul class='list'>
	<li>可乐游戏平台 <a href="http://www.ctrlz.cn" target="_blank">www.ctrlz.cn</a></li>	
	<li  style="background:#efefef">QQ：314839</li>	
	</ul>
	</div>
</td>
</tr>
</table>

</body>
</html>