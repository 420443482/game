<?php
/**
 *推广相关接口类
*/
function sp_gateway($userid,$username,$spid,$params){
	//exit;
}
?>