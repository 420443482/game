<?php
$db_host='localhost';
$db_user='root';
$db_password='root';
$db_name='oss_list';
$db_prefix='oss_';
?>
