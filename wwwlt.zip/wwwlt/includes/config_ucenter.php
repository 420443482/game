<?php
define('UC_CONNECT', 'mysql');
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', '123690');
define('UC_DBNAME', 'ossbbs');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`ossbbs`.oss_ucenter_');
define('BBS_DBTABLEPRE', '`ossbbs`.oss_');
define('UC_DBCONNECT', '0');
define('UC_KEY', '4f5da607d06100785376146b1f678207');
define('UC_API', 'http://bbs.ctrlz.cn/uc_server');
define('UC_CHARSET', 'utf8');
define('UC_IP', '');
define('UC_APPID', '2');
define('UC_PPP', '20');

//ͬ����¼ Cookie ����
$cookiedomain = 'ctrlz.cn';
$cookiepath = '/';
?>